import sys

from django.http import HttpResponse, HttpResponseRedirect
from .models import  Question, Choice
from django.shortcuts import render, get_object_or_404
from django.urls import reverse
from django.utils import timezone

#index page- latest few questions
#detail page - question text, form to vote
#results page - display results for a particular question
#Vote action - handles voting for the particular choice

def index(request):
    #get the top 5 question recently created
    latest_question_list = Question.objects.order_by("-pub_date")
    context = {
        "latest_question_list": latest_question_list
    }
    return render(request,"index.html",context)


def detail(request, question_id):#/polls/1, /polls/2
    question = get_object_or_404(Question,pk=question_id)
    return render(request,"details.html", {"question":question})

def results(request, question_id):
    question = get_object_or_404(Question,pk=question_id)
    return render(request,"results.html",{"question":question})


def vote(request,question_id):
    question = get_object_or_404(Question,pk=question_id)
    try:
        selected_choice = question.answers.get(pk=request.POST['choice'])
    except (KeyError, Choice.DoesNotExist):
        return render(request,"details.html", {
            "question":question,
            "error_message":"You didn't select a choice"
        })
    else:
        selected_choice.votes += 1
        selected_choice.save()
        return HttpResponseRedirect(reverse('results',args=(question_id,)))


def create_question(request):
    try:
        if request.method == "POST":
            question = Question.objects.create(questions = request.POST["questions"],
                                       pub_date = timezone.now(),
                                        created_at = timezone.now())
        else:
            return render(request, "create_question.html", {"error_message": ""})
    except:
        return render(request,"create_question.html", {"error_message":sys.exc_info()[1].__str__()})
    else:
        return HttpResponseRedirect(reverse('index'))


"""
Create a Url and view for creating a choice
"""